create function st_intersection(geography, geography)
  returns geography
immutable
strict
parallel safe
language sql
as $$
SELECT geography(ST_Transform(ST_Intersection(ST_Transform(geometry($1), public._ST_BestSRID($1, $2)), ST_Transform(geometry($2), public._ST_BestSRID($1, $2))), 4326))
$$;

comment on function st_intersection(geography, geography)
is 'args: geogA, geogB - (T)Returns a geometry that represents the shared portion of geomA and geomB.';

