create function st_approxcount(rast raster, exclude_nodata_value boolean, sample_percent double precision DEFAULT 0.1)
  returns bigint
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_count($1, 1, $2, $3)
$$;

