create function st_valuecount(rast raster, nband integer, exclude_nodata_value boolean, searchvalue double precision, roundto double precision DEFAULT 0)
  returns integer
immutable
strict
parallel safe
language sql
as $$
SELECT ( public._ST_valuecount($1, $2, $3, ARRAY[$4]::double precision[], $5)).count
$$;

comment on function st_valuecount(rast        raster, nband integer, exclude_nodata_value boolean,
                                  searchvalue double precision, roundto double precision DEFAULT 0)
is 'args: rast, nband, exclude_nodata_value, searchvalue, roundto=0 - Returns a set of records containing a pixel band value and count of the number of pixels in a given band of a raster (or a raster coverage) that have a given set of values. If no band is specified defaults to band 1. By default nodata value pixels are not counted. and all other values in the pixel are output and pixel band values are rounded to the nearest integer.';

