create function st_approxquantile(rastertable text, rastercolumn text, nband integer, exclude_nodata_value boolean, sample_percent double precision, quantile double precision)
  returns double precision
stable
strict
language sql
as $$
SELECT ( public._ST_quantile($1, $2, $3, $4, $5, ARRAY[$6]::double precision[])).value
$$;

